import React from 'react'

export default function Page404() {
  return (
    <div className='container'>
      <h2>Page 404, page not found!</h2>
    </div>
  )
}
